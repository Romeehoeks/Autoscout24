# set your own working dic
setwd("/../../autoscout")

# install packages
install.packages("tidyverse")
install.packages("dplyr")
library(tidyverse)
library(dplyr)

# load file
df_new5 <- read_csv("autoscout_outfile_def.csv")

# head of data frame
head(df_new5)

# group by brand, count
df_brand <- df_new5 %>% 
  group_by(Merk) %>% 
  count(Merk)

# statistics on price
df_new5$prijs <- as.numeric(gsub('[€,-]', '', df_new5$prijs))
summary(df_new5$prijs)

